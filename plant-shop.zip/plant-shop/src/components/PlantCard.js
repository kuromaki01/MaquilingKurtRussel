import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../features/cartSlice';

export default function PlantCard({ plant }) {
    const dispatch = useDispatch();
    const items = useSelector(s => s.cart.items);
    const isAdded = !!items[plant.id];

    const handleAdd = () => {
        if (!isAdded) dispatch(addToCart(plant));
    }

    return ( <
        div className = "card-plant" >
        <
        img src = { plant.image }
        alt = { plant.name }
        /> <
        h3 > { plant.name } < /h3> <
        p className = "price" > $ { plant.price.toFixed(2) } < /p> <
        p className = "small" > { plant.category } < /p> <
        button onClick = { handleAdd }
        disabled = { isAdded }
        className = "btn"
        style = {
            { marginTop: 12, borderRadius: 8, padding: '8px 12px', background: isAdded ? '#9ca69a' : undefined } } > { isAdded ? 'Added' : 'Add to Cart' } <
        /button> <
        /div>
    );
}