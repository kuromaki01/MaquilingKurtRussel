import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

export default function Header() {
    const totalItems = useSelector((s) => s.cart.totalItems);

    return ( <
        header style = {
            {
                background: "#065f46",
                borderBottom: "2px solid #064e3b",
                padding: "12px 20px",
                position: "sticky",
                top: 0,
                zIndex: 50,
            }
        } >
        <
        div style = {
            {
                display: "flex",
                flexDirection: "column", // stack logo and nav
                alignItems: "center",
                justifyContent: "center",
                gap: "6px",
                maxWidth: "1200px",
                margin: "0 auto",
            }
        } >
        { /* Logo */ } <
        h1 style = {
            { margin: 0, fontSize: "1.8rem", fontWeight: 700, color: "white" } } > 🌿Greenhouse <
        /h1>

        { /* Nav */ } <
        nav style = {
            { display: "flex", gap: "28px", alignItems: "center" } } >
        <
        Link to = "/"
        style = {
            {
                color: "white",
                textDecoration: "none",
                fontWeight: 500,
            }
        } >
        Home <
        /Link> <
        Link to = "/products"
        style = {
            {
                color: "white",
                textDecoration: "none",
                fontWeight: 500,
            }
        } >
        Products <
        /Link> <
        Link to = "/cart"
        style = {
            {
                color: "white",
                textDecoration: "none",
                fontWeight: 600,
                display: "flex",
                alignItems: "center",
                gap: "6px",
            }
        } >
        🛒Cart({ totalItems }) <
        /Link> <
        /nav> <
        /div> <
        /header>
    );
}