import { useSelector, useDispatch } from 'react-redux';
import { increase, decrease, remove } from '../features/cartSlice';
import { Link } from 'react-router-dom';

export default function ShoppingCartPage() {
    const { items, totalItems, totalPrice } = useSelector(s => s.cart);
    const dispatch = useDispatch();

    const itemList = Object.values(items);

    return ( <
        div className = "cart-page" >
        <
        div className = "container" >
        <
        h2 style = {
            { fontSize: 28 } } > Your Cart < /h2> <
        p className = "small" >
        Total Items: { totalItems }·
        Total Price: $ { totalPrice.toFixed(2) } <
        /p>

        <
        div className = "cart-list" > {
            itemList.length === 0 && ( <
                div style = {
                    { padding: 20, background: '#fff', borderRadius: 10 } } >
                Your cart is empty. <
                Link to = "/products"
                className = "btn secondary"
                style = {
                    { marginLeft: 8 } } >
                Shop plants <
                /Link> <
                /div>
            )
        } {
            itemList.map(({ plant, quantity }) => ( <
                div key = { plant.id }
                className = "cart-item" >
                <
                img src = { plant.image }
                alt = { plant.name }
                /> <
                div style = {
                    { flex: 1 } } >
                <
                h3 style = {
                    { margin: 0 } } > { plant.name } < /h3> <
                p className = "small" > Unit price: $ { plant.price.toFixed(2) } < /p> <
                p className = "small" > Quantity: { quantity } < /p> <
                /div> <
                div className = "kv" >
                <
                div className = "qty-controls"
                style = {
                    { display: 'flex', gap: 8, alignItems: 'center' } } >
                <
                button onClick = {
                    () => dispatch(increase(plant.id)) }
                className = "btn" > + < /button> <
                button onClick = {
                    () => dispatch(decrease(plant.id)) }
                className = "btn secondary" > - < /button> <
                /div> <
                button onClick = {
                    () => dispatch(remove(plant.id)) }
                className = "delete" > Delete < /button> <
                /div> <
                /div>
            ))
        } <
        /div>

        <
        div style = {
            { marginTop: 20, display: 'flex', gap: 12 } } >
        <
        button className = "btn secondary"
        onClick = {
            () => alert('Coming Soon') } > Checkout < /button> <
        Link to = "/products"
        className = "btn" > Continue Shopping < /Link> <
        /div> <
        /div> <
        /div>
    );
}