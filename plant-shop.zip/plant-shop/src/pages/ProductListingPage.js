import plants from '../data/plants';
import PlantCard from '../components/PlantCard';
import Header from '../components/Header';

export default function ProductListingPage() {
    const categories = [...new Set(plants.map(p => p.category))];
    return ( <
            div className = "products-page" >
            <
            div className = "container" > {
                categories.map(cat => ( <
                        section key = { cat }
                        style = {
                            { marginBottom: 28 } } >
                        <
                        h2 style = {
                            { fontSize: 22, marginBottom: 12 } } > { cat } < /h2> <
                        div className = "grid" > {
                            plants.filter(p => p.category === cat).map(p => < PlantCard key = { p.id }
                                plant = { p }
                                />)} <
                                /div> <
                                /section>
                            ))
                    } <
                    /div> <
                    /div>
                );
            }