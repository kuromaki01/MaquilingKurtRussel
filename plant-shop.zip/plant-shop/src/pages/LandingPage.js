import { Link } from 'react-router-dom';

export default function LandingPage(){
  return (
    <div className="landing">
      <div className="card">
        <h2 style={{fontSize:42, margin:'6px 0'}}>Welcome to <span style={{color:'#19692f'}}>Greenhouse</span></h2>
        <p style={{fontSize:18, margin:'12px 0'}}>Bring the calm and life of nature into your home. We curate easy-care houseplants that fit any space — from low-light corners to sunny windowsills.</p>
        <Link to="/products" className="btn">Get Started</Link>
        <p className="footer-note">Free local delivery on orders over $50. Sustainably sourced plants.</p>
      </div>
    </div>
  );
}
