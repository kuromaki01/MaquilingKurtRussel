import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  items: {}, // { plantId: { plant, quantity } }
  totalItems: 0,
  totalPrice: 0,
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const plant = action.payload;
      if (!state.items[plant.id]) {
        state.items[plant.id] = { plant, quantity: 1 };
      } else {
        state.items[plant.id].quantity += 1;
      }
      state.totalItems += 1;
      state.totalPrice = parseFloat((state.totalPrice + plant.price).toFixed(2));
    },
    increase: (state, action) => {
      const id = action.payload;
      if (state.items[id]) {
        state.items[id].quantity += 1;
        state.totalItems += 1;
        state.totalPrice = parseFloat((state.totalPrice + state.items[id].plant.price).toFixed(2));
      }
    },
    decrease: (state, action) => {
      const id = action.payload;
      if (state.items[id] && state.items[id].quantity > 1) {
        state.items[id].quantity -= 1;
        state.totalItems -= 1;
        state.totalPrice = parseFloat((state.totalPrice - state.items[id].plant.price).toFixed(2));
      }
    },
    remove: (state, action) => {
      const id = action.payload;
      if (state.items[id]) {
        state.totalItems -= state.items[id].quantity;
        state.totalPrice = parseFloat((state.totalPrice - state.items[id].quantity * state.items[id].plant.price).toFixed(2));
        delete state.items[id];
      }
    },
    clear: (state) => {
      state.items = {};
      state.totalItems = 0;
      state.totalPrice = 0;
    },
  },
});

export const { addToCart, increase, decrease, remove, clear } = cartSlice.actions;
export default cartSlice.reducer;
