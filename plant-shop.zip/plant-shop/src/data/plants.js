const plants = [
    { id: 1, name: "Snake Plant", price: 15.00, category: "Low Light", image: "/plants/snake.jpg" },
    { id: 2, name: "Peace Lily", price: 20.00, category: "Flowering", image: "/plants/peace.jpg" },
    { id: 3, name: "Aloe Vera", price: 18.00, category: "Succulent", image: "/plants/aloe.jpg" },
    { id: 4, name: "Fiddle Leaf Fig", price: 35.00, category: "Large Plants", image: "/plants/fiddle.jpg" },
    { id: 5, name: "Spider Plant", price: 12.00, category: "Air Purifying", image: "/plants/spider.jpg" },
    { id: 6, name: "Cactus", price: 10.00, category: "Succulent", image: "/plants/cactus.jpg" },
];

export default plants;