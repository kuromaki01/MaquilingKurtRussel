# Plant Shop - Starter Project

Colorful "garden vibe" React + Redux starter project (plain CSS).

## How to run
1. unzip
2. `npm install`
3. `npm start`

This project contains a small Redux store to manage the shopping cart and fulfills the rubric requirements:
- Landing page with background image, company name, paragraph, and Get Started button
- Product listing with 6 plants in categories
- Add to Cart behavior and cart page with increase/decrease/delete
